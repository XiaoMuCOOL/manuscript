(function ($) {
    $.mobiscroll.i18n.it = $.extend($.mobiscroll.i18n.it, {
        setText: 'OK',
        cancelText: 'Annulla'
    });
})(jQuery);
