(function ($) {
    $.mobiscroll.i18n.de = $.extend($.mobiscroll.i18n.de, {
        setText: 'OK',
        cancelText: 'Abbrechen'
    });
})(jQuery);
